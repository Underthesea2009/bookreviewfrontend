Capstone Project instructions for Fullstack teammates:

FrontEnd instructions:
npm install
npm run dev

BackEnd Instructions:
npm init -y
npm install - - save express
npm install pg
npm install cors

.env file should have the following:
PORT=3006

PGUSER=postgres
PGHOST=localhost
PGPASSWORD=password
PGDATABASE=yelp
PGPORT=5432

server.js should have the following:
require("dotenv").config();

In seed.js choose proper password in the following format:
    process.env.DATABASE_URL ||
    "https://postgres:password@localhost:5432/bookclub",
Note that “bookclub” is the psql database.

In psql create database bookclub;
Don’t forget the semicolon.

Then, npm run seed
This will seed your data.

Fix the cors policy inhibition problem by the following:
    1.    In backend folder install cors with: npm install cors
    2.    In api folder index.js add the following lines of code.
    •    const cors = require("cors");
    •    apiRouter.use(cors());
