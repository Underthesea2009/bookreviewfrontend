import { useState } from "react";

export default function Login({ token, setToken, setUserStatus }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleUsernameChange = (e) => {
    setUsername(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleLogin = async (e) => {
    e.preventDefault();

    if (token) {
      setToken(null);
      setUserStatus(null);
      return;
    }

    const authenticationEndpoint = "http://localhost:3006/api/v1/users/login";

    try {
      const response = await fetch(authenticationEndpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      });
      console.log("login response", response);
      const data = await response.json();
      console.log(data);

      if (response.ok) {
        // Check the response from the server for successful login
        if (data.token) {
          setToken(data.token);
          setUserStatus(data.status);
          alert("Successful Login🥂!!");
          console.log("Login successful");
          setError("");
        } else {
          setToken(null);
          setUserStatus(null);
          console.log("Login failed");
          setError("Invalid username or password");
          alert(`Bummer😱!! ${data.message}`);
        }
      } else {
        console.log("Login failed");
        setError("An error occurred during login");
      }
      setUsername("");
      setPassword("");
    } catch (error) {
      console.error("Error during login:", error);
      setError("An error occurred during login");
    }
  };

  return (
    <div className="login">
      <h1>Login Component</h1>
      <form onSubmit={handleLogin}>
        {!token && (
          <div>
            <label htmlFor="username"></label>
            <input
              type="text"
              placeholder="Username"
              id="username"
              value={username}
              onChange={handleUsernameChange}
              required
            />
          </div>
        )}
        {!token && (
          <div>
            <label htmlFor="password"></label>
            <input
              type="password"
              placeholder="Password"
              id="password"
              value={password}
              onChange={handlePasswordChange}
              required
            />
          </div>
        )}
        <button type="submit">{token ? "Logout" : "Login"}</button>
        {error && <p className="error">{error}</p>}
      </form>
    </div>
  );
}