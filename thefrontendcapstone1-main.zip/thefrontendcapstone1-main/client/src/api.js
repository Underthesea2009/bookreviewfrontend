export const BASE_URL = "http://localhost:3006/api/v1";
