import React, { useState } from "react"; // Import React and useState hook

// Import necessary components
import AddBook from "../components/AddBook";
import BookList from "../components/BookList";
import UserList from "../components/UserList";

const AdminPage = ({
  token,
  userStatus,
  updateIfChanged,
  setUpdateIfChanged,
  user_id,
}) => {
  const [isShowingUsers, setIsShowingUsers] = useState(false);

  const [isShowingAddBook, setIsShowingAddBook] = useState(false);

  const [isShowingForEditing, setIsShowingForEditing] = useState(false);

  return (
    <>
      <h1>😎Administration Page</h1>
      <br />
      <h2 className="subtitles">
        List of Users:
        <button
          id="add"
          style={{ marginLeft: 20 }}
          onClick={() => {
            setIsShowingUsers(!isShowingUsers);
          }}
        >
          {isShowingUsers ? "HIDE" : "SHOW"}
        </button>
      </h2>
      {isShowingUsers && <UserList />}

      <br />
      <h2 className="subtitles">
        Add A Book:
        <button
          id="add"
          style={{ marginLeft: 20 }}
          onClick={() => {
            setIsShowingAddBook(!isShowingAddBook);
          }}
        >
          {isShowingAddBook ? "HIDE" : "SHOW"}
        </button>
      </h2>
      {isShowingAddBook && <AddBook setUpdateIfChanged={setUpdateIfChanged} />}
      <br />

      <h2 className="subtitles">
        Edit Book List, Reviews, & Ratings:
        <button
          id="add"
          style={{ marginLeft: 20 }}
          onClick={() => {
            setIsShowingForEditing(!isShowingForEditing);
          }}
        >
          {isShowingForEditing ? "HIDE" : "SHOW"}
        </button>
      </h2>
      {isShowingForEditing && (
        <BookList
          token={token}
          userStatus={userStatus}
          updateIfChanged={updateIfChanged} // Pass state variable to trigger updates
          setUpdateIfChanged={setUpdateIfChanged} // Pass down a function to update if changed
          user_id={user_id}
        />
      )}
      <br />
    </>
  );
};

export default AdminPage; // Export the AdminPage component
