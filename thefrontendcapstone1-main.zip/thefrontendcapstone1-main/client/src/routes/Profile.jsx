import React from "react";
import UserCommentList from "../components/UserCommentList";
import UserIntro from "../components/UserIntro";

const Profile = ({ token, userStatus, user_id }) => {
  return (
    <div>
      <UserIntro token={token} userStatus={userStatus} user_id={user_id} />
      <h2 className="subtitles">Edit Book Reviews & Ratings:</h2>

      <UserCommentList
        token={token}
        userStatus={userStatus}
        user_id={user_id}
      />
    </div>
  );
};

export default Profile;
