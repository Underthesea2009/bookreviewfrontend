import React, { useState } from "react";
import Header from "../components/Header";
import BookList from "../components/BookList";

export default function Home({
  token,
  userStatus,
  user_id,
  updateIfChanged,
  setUpdateIfChanged,
}) {
  return (
    <div>
      <br />
      <Header />

      <BookList
        token={token}
        userStatus={userStatus}
        updateIfChanged={updateIfChanged}
        setUpdateIfChanged={setUpdateIfChanged}
        user_id={user_id}
      />
    </div>
  );
}
