import React, { useState } from "react";
import axios from "axios";
import { BASE_URL } from "../api";

const Signup = ({ setUserToken }) => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    username: "",
    password: "",
    status: "member",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value.toLowerCase() });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(formData); // Log the formData before sending it
    setFormData({ ...formData, ["username"]: formData.username.toLowerCase() });

    console.log(formData.username);
    if (formData.username.length < 6 || formData.password.length < 6) {
      alert("Username & Password must be greater than 5 characters");
      return;
    }
    try {
      const response = await axios.post(`${BASE_URL}/users`, formData);
      console.log(response.data); // Handle the response data
      console.log(response.data.error);
      if (response.data.error) {
        alert(`Sign up was unsuccessful. ${response.data.message}`);
      } else {
        alert("Successful Signup🥂!!");
      }
    } catch (error) {
      console.error("Error:", error); // Handle errors
    }
  };

  return (
    <div>
      <h1>Signup✏️</h1>
      <form onSubmit={handleSubmit}>
        <div className="user-input-box">
          <input
            type="text"
            placeholder="Name"
            name="name"
            value={formData.name}
            onChange={handleChange}
          />{" "}
          <br /> <br />
        </div>
        <div className="user-input-box">
          <input
            type="email"
            placeholder="Email"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />{" "}
          <br /> <br />
        </div>
        <div className="user-input-box">
          <input
            type="text"
            placeholder="Username"
            name="username"
            value={formData.username}
            onChange={handleChange}
          />{" "}
          <br /> <br />
        </div>

        <div className="user-input-box">
          <input
            type="password"
            placeholder="Password"
            name="password"
            value={formData.password}
            onChange={handleChange}
          />{" "}
          <br /> <br />
        </div>
        <button type="submit">SIGNUP</button>
      </form>
    </div>
  );
};

export default Signup;
