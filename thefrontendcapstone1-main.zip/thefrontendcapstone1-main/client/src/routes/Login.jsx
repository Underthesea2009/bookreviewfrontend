import { useState } from "react";

// Define the Login component taking in token, setToken, setUserStatus, and setUser_id as props
export default function Login({ token, setToken, setUserStatus, setUser_id }) {
  // State variables to hold username, password, and error messages
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  // Functions to handle changes in the username and password input fields
  const handleUsernameChange = (e) => {
    setUsername(e.target.value.toLowerCase());
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  // Function to handle the login process
  const handleLogin = async (e) => {
    e.preventDefault(); // Prevent the default form submission behavior

    // If the user is already logged in, clear token and user status and return
    if (token) {
      setToken(null);
      setUserStatus(null);
      setUser_id(null);
      return;
    }

    // Define the authentication endpoint
    const authenticationEndpoint = "http://localhost:3006/api/v1/users/login";

    try {
      // Make a POST request to the authentication endpoint with username and password
      const response = await fetch(authenticationEndpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      });

      // Log the response and parse the JSON data from the response
      console.log("login response", response);
      const data = await response.json();
      console.log(data);

      // Check if the response is successful
      if (response.ok) {
        // Checks the response from the server for successful login
        if (data.token) {
          setToken(data.token);
          setUserStatus(data.status);
          setUser_id(data.user_id);
          alert("Successful Login🥂!!");
          console.log("Login successful");
          setError("");
        } else {
          // If the server response does not contain a token, handle failed login
          setToken(null);
          setUserStatus(null);
          setUser_id(false);
          console.log("Login failed");
          setError("Invalid username or password");
          alert(`Bummer😱!! ${data.message}`);
        }
      } else {
        // If the response is not successful, handle login failure
        console.log("Login failed");
        setError("An error occurred during login");
      }

      // Reset username and password fields after login attempt
      setUsername("");
      setPassword("");
    } catch (error) {
      // Handle errors that occurred during the login process
      console.error("Error during login:", error);
      setError("An error occurred during login");
    }
  };

  // Render the login form
  return (
    <div className="login">
      <h1>📚 Book Review Club 📚</h1>
      <form onSubmit={handleLogin}>
        {!token && (
          <div className="user-input-box">
            <label htmlFor="username"></label>
            <input
              type="text"
              placeholder="Username"
              id="username"
              value={username}
              onChange={handleUsernameChange}
              required
            />{" "}
            <br /> <br />
          </div>
        )}
        {!token && (
          <div>
            <label htmlFor="password"></label>
            <input
              type="password"
              placeholder="Password"
              id="password"
              value={password}
              onChange={handlePasswordChange}
              required
            />{" "}
            <br /> <br />
          </div>
        )}
        <button type="submit">{token ? "LOGOUT" : "LOGIN"}</button>
        {error && <p className="error">{error}</p>}
      </form>
    </div>
  );
}
