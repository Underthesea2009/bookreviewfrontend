import React, { useState } from "react";
import { BASE_URL } from "../api";

const Genre = ({ genre, setUpdateIfChanged }) => {
  const [name, setName] = useState(genre.name);

  async function handleSave(e) {
    e.preventDefault();
    console.log("Submit event");
    try {
      const response = await fetch(`${BASE_URL}/genres/${genre.genre_id}`, {
        method: "PATCH",
        body: JSON.stringify({
          name: name,
        }),
        headers: {
          "Content-Type": "application/json",
          // Authorization: `Bearer ${token}`,
        },
      });
      const result = await response.json();
      console.log(result);
      return result;
    } catch (err) {
      console.error(err);
    }
  }
  async function handleDelete(e) {
    e.preventDefault();
    console.log("Delete event");
    try {
      const response = await fetch(`${BASE_URL}/genres/${genre.genre_id}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          // Authorization: `Bearer ${token}`,
        },
      });
      const result = await response.json();
      setUpdateIfChanged(result);
      console.log(result);
      return result;
    } catch (err) {
      console.error(err);
    }
  }
  return (
    <div>
      <h3>{genre.name}</h3>
      <form onSubmit={handleSave}>
        <label>
          genre name:
          <input
            type="text"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
            }}
          />
        </label>

        <button id="add" type="submit">
          Save
        </button>
        <button type="button" onClick={handleDelete}>
          Delete
        </button>
      </form>
    </div>
  );
};

export default Genre;