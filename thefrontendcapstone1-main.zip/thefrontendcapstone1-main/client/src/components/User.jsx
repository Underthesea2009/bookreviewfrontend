import { useState } from "react";

export default function User({ user }) {
  return (
    <div className="user">
      <div className="item">{`Name: ${user.name}`}</div>
      <div className="item">{user.email}</div>
      <div className="item">{`Username: ${user.username}`}</div>
      <div className="item">{`Status: ${user.status}`}</div>
      <br />
    </div>
  );
}
