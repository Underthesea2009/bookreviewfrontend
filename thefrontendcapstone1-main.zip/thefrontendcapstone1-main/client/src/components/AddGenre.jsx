import React from "react";
import { useState } from "react";
import { BASE_URL } from "../api";

const AddGenre = ({ setUpdateIfChanged }) => {
  const [name, setName] = useState("name");

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      const response = await fetch(`${BASE_URL}/genres`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name,
        }),
      });
      const newGenre = await response.json();
      setUpdateIfChanged(newGenre);
      console.log(newGenre);
    } catch (error) {
      console.error(error);
    }
  }

  return (
    <div className="addgenre">
      <h1>ADD GENRE Component</h1>

      <form onSubmit={handleSubmit}>
        <label>
          Name
          <input
            type="text"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
            }}
          />
        </label>
        <button id="add" type="submit">
          Add A Genre
        </button>
        <br />
        <br />
      </form>
    </div>
  );
};
export default AddGenre;