import { useState } from "react";
import Book from "./Book";

export default function Books({
  books,
  token,
  userStatus,
  setUpdateIfChanged,
  user_id,
  setUpdateRatingIfChanged,
}) {
  return (
    <>
      <div className="booklist">
        {books &&
          books.map((book) => {
            return (
              <Book
                book={book}
                token={token}
                userStatus={userStatus}
                setUpdateIfChanged={setUpdateIfChanged}
                key={book.book_id}
                user_id={user_id}
                setUpdateRatingIfChanged={setUpdateRatingIfChanged}
              />
            );
          })}
      </div>
    </>
  );
}
