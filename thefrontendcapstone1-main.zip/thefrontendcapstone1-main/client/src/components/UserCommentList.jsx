import { useEffect, useState } from "react";
import UserComment from "./UserComment";
import { BASE_URL } from "../api";

export default function UserCommentList({ token, userStatus, user_id }) {
  const [comments, setComments] = useState([]);
  const [updateIfChanged, setUpdateIfChanged] = useState(null);
  async function fetchComments() {
    try {
      console.log("Attempting to fetch comments from book_id:" + user_id);
      const response = await fetch(
        `${BASE_URL}/comments/bookCommentsByUser/${user_id}`
      );
      const results = await response.json();
      console.log(results.bookComment);
      setComments(results.bookComment);
      console.log("Fetched results from fetchComments()", results);
      return results;
    } catch (err) {
      console.error("Trouble fetching UserCommentList!", err);
    }
  }

  useEffect(() => {
    fetchComments();
  }, [updateIfChanged]);
  return (
    <>
      <div className="UserCommentList">
        <h2>Comments 💬</h2>

        {comments &&
          comments.map((comment) => {
            return (
              <UserComment
                comment={comment}
                token={token}
                userStatus={userStatus}
                setUpdateIfChanged={setUpdateIfChanged}
                key={comment.comment_id}
              />
            );
          })}
      </div>
    </>
  );
}
