/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import { useEffect, useState } from "react";
import { BASE_URL } from "../api";

export default function Comment({
  comment,
  token,
  userStatus,
  setUpdateIfChanged,
}) {
  const [username, setUsername] = useState("Unknown User");
  async function handleDelete() {
    const url = `${BASE_URL}/comments/${comment.comment_id}`;
    console.log("Deleting comment from ", url);

    try {
      const response = await fetch(url, {
        method: "DELETE",
      });
      setUpdateIfChanged(response);
      console.log("This comment was deleted", response);
    } catch (error) {
      console.log(error);
    }
  }
  async function getUsernameByID() {
    const url = `${BASE_URL}/users/${comment.user_id}`;
    try {
      const response = await fetch(url);
      const results = await response.json();
      console.log("getting Username By ID: ");
      console.log(results);
      setUsername(results.user.username);
    } catch (error) {
      console.log(error);
    }
  }
  useEffect(() => {
    getUsernameByID();
  }, []);
  return (
    <>
      <div>
        <span>{username} - </span>
        <span>{comment.content}</span>
        <div>{`Rating: ${comment.rating}`}</div>
        <br />
      </div>
    </>
  );
}
