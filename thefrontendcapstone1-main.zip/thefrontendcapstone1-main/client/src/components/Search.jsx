import { useState } from "react";

export default function Search() {
  const [searchText, setSearchText] = useState("");
  function filterBooks(book) {
    return searchText === ""
      ? book
      : book.title.toLowerCase().includes(searchText.toLowerCase());
  }

  return (
    <div className="search">
      <label className="search">
        Search
        <input
          type="text"
          placeholder="Looking for..."
          value={searchText}
          onChange={(e) => {
            setSearchText(e.target.value);
          }}
        />
      </label>
    </div>
  );
}