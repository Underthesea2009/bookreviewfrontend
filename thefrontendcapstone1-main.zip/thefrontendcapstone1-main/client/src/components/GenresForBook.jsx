import React from "react";

const GenresForBook = ({ genres }) => {
  return (
    <div className="horiz">
      {genres &&
        genres.map((genre) => {
          return (
            <div className="genre" key={genre.genre_id}>
              {genre.name}
            </div>
          );
        })}
    </div>
  );
};

export default GenresForBook;
