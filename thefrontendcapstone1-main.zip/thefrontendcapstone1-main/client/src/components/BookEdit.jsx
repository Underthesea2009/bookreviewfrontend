import React, { useEffect, useState } from "react";
import { BASE_URL } from "../api";
import GenrePickerView from "./GenrePickerView";

const BookEdit = ({ book, setUpdateIfChanged }) => {
  const [title, setTitle] = useState(book.title);
  const [author, setAuthor] = useState(book.author);
  const [description, setDescription] = useState(book.description);
  const [active, setActive] = useState(true);
  const [image_Url, setImage_Url] = useState(book.image_url);
  const [selectedGenres, setSelectedGenres] = useState([]);
  const [initialGenres, setInitialGenres] = useState([]);

  async function fetchGenresForBook() {
    try {
      const response = await fetch(`${BASE_URL}/bookgenres/${book.book_id}`);
      const { genres } = await response.json();
      console.log("Fetched Genres: *****************");

      setSelectedGenres(genres);
      setInitialGenres(genres);
      console.log(selectedGenres);
    } catch (error) {
      throw error;
    }
  }

  async function handleEdit(e) {
    e.preventDefault();

    const url = `${BASE_URL}/books/${book.book_id}`;
    console.log("Editing book from ", url);

    const newBook = {};
    newBook.book_id = book.book_id;
    newBook.title = title;
    newBook.author = author;
    newBook.rating = 5.0;
    newBook.description = description;
    newBook.genre_id = 1;
    newBook.image_url = image_Url;
    newBook.active = true;

    console.log(newBook);
    try {
      const response = await fetch(url, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newBook),
      });
      const result = await response.json();
      deleteAllGenresFromBook;
      console.log("This book was modified", result);
    } catch (error) {
      console.error(error);
    }
  }
  async function deleteAllGenresFromBook(book_id) {
    selectedGenres.forEach(async (genre) => {
      await deleteGenreFromBook(genre, book_id);
    });
    console.log("deleteAllGenresToBook: selectedGenres = ", selectedGenres);
  }
  async function deleteGenreFromBook(genre, book_id) {
    const url = `${BASE_URL}/bookGenres/${book_id}`;

    try {
      const response = await fetch(url, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ genre_id: genre.genre_id }),
      });
      const data = await response.json();
      console.log(data);
    } catch (error) {
      console.error(error);
    }
  }
  async function addAllGenresToBook(book_id) {
    selectedGenres.forEach(async (genre) => {
      await addGenreToBook(genre, book_id);
    });
    console.log("addAllGenresToBook: selectedGenres = ", selectedGenres);
  }
  async function addGenreToBook(genre, book_id) {
    const url = `${BASE_URL}/bookGenres/${book_id}`;
    const book_genre = {
      book_id: book_id,
      genre_id: genre.genre_id,
    };

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(book_genre),
      });
      const data = await response.json();
      console.log(data);
    } catch (error) {
      console.error(error);
    }
  }

  useEffect(() => {
    fetchGenresForBook();
  }, []);

  return (
    <div className="update-book">
      <div className="flexgrow">
        <form onSubmit={handleEdit}>
          <div className="form-row">
            <div className="col">
              <input
                type="text"
                className="form-control"
                placeholder="Title"
                value={title}
                onChange={(e) => {
                  setTitle(e.target.value);
                }}
              />
            </div>
            <div className="col">
              <input
                className="form-control"
                type="text"
                placeholder="Author"
                value={author}
                onChange={(e) => {
                  setAuthor(e.target.value);
                }}
              />
            </div>
            <div className="col">
              <input
                className="form-control"
                type="text"
                placeholder="Description"
                value={description}
                onChange={(e) => {
                  setDescription(e.target.value);
                }}
              />
            </div>
            <div className="col">
              <input
                className="form-control"
                type="text"
                placeholder="Image URL"
                value={image_Url}
                onChange={(e) => {
                  setImage_Url(e.target.value);
                }}
              />
              <br />
            </div>
            <br />
          </div>
          <div className="update-book">
            <br />
            <button id="add" type="submit">
              UPDATE
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BookEdit;
