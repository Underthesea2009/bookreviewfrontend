export default function SelectedBook() {
  return (
    <div className="selectedbook">
      <h1>SELECTEDBOOK Component</h1>
    </div>
  );
}
