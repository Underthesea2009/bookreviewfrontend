import React from "react";

const Header = () => {
  return (
    <div>
      <h1>📚 Book Review Club 📚</h1>
    </div>
  );
};

export default Header;
