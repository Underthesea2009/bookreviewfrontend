import { useEffect, useState } from "react";
import Book from "./Book";
import { BASE_URL } from "../api";
import Books from "./Books";

export default function BookList({
  token,
  userStatus,
  updateIfChanged,
  setUpdateIfChanged,
  user_id,
}) {
  const [books, setBooks] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredBooks, setFilteredBooks] = useState([]);
  const [updateRatingIfChanged, setUpdateRatingIfChanged] = useState(null);

  async function fetchBooks() {
    try {
      const response = await fetch(`${BASE_URL}/books`);
      const results = await response.json();
      setBooks(results.allBooks);
      setFilteredBooks(results.allBooks);
    } catch (err) {
      console.error("Trouble fetching books!", err);
    }
  }

  useEffect(() => {
    fetchBooks();
  }, [updateIfChanged, updateRatingIfChanged]);

  useEffect(() => {
    setFilteredBooks(filterBooks());
  }, [searchTerm]);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value.toLowerCase());
  };

  function filterBooks() {
    if (!searchTerm) {
      return books;
    }
    return books.filter((book) => {
      return (
        book.title.toLowerCase().includes(searchTerm) ||
        book.author.toLowerCase().includes(searchTerm)
      );
    });
  }

  return (
    <>
      <div className="search">
        <label className="search">
          <input
            type="text"
            placeholder="Search for books..."
            value={searchTerm}
            onChange={handleSearch}
          />
        </label>
      </div>
      <br />
      <Books
        books={filteredBooks}
        token={token}
        userStatus={userStatus}
        setUpdateIfChanged={setUpdateIfChanged}
        user_id={user_id}
        setUpdateRatingIfChanged={setUpdateRatingIfChanged}
      />
    </>
  );
}
