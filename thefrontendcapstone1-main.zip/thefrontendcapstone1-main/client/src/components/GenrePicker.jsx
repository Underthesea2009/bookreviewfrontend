import React, { useEffect, useState } from "react";
import Genre from "./Genre";
import AddGenre from "./AddGenre";
import { BASE_URL } from "../api";

const GenrePicker = ({ genre, setGenre }) => {
  const [genres, setGenres] = useState([]);
  const [updateIfChanged, setUpdateIfChanged] = useState(null);

  async function fetchGenres() {
    try {
      const response = await fetch(`${BASE_URL}/genres`);
      const results = await response.json();
      setGenres(results.allGenres);
      console.log("Fetched results from fetchGenres()", results);
      return results;
    } catch (err) {
      console.error("Trouble fetching GenreList!", err);
    }
  }

  useEffect(() => {
    fetchGenres();
  }, [updateIfChanged]);
  return (
    <div className="genrecontainer">
      <AddGenre setUpdateIfChanged={setUpdateIfChanged} />
      <h2>Genre Picker</h2>
      {`Selected Genre: ${genre ? genre.name : "No genre selected"}`}

      {genres &&
        genres.map((genre) => {
          return <div className="genre-cell">{genre.name}</div>;
        })}
    </div>
  );
};

export default GenrePicker;
