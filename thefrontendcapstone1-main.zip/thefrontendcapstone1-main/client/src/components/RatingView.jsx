import React from "react";

const RatingView = ({ rating }) => {
  function convertRatingToArray() {
    const limit = Math.round(rating);
    const starArray = [];
    for (let i = 0; i < limit; i += 1) {
      starArray.push({ icon: "⭐️", id: i });
    }
    console.log("limit", limit);
    console.log(starArray);
    return starArray;
  }
  return (
    <>
      <div style={{ width: 200 }}>{`rating: ${
        rating ? Math.round(rating * 10) / 10 : "none"
      }`}</div>
      {convertRatingToArray().map((star) => {
        return <span key={star.id}>⭐️</span>;
      })}
    </>
  );
};

export default RatingView;
