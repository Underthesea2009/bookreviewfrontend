import { useEffect, useState } from "react";
import Comment from "./Comment";
import { BASE_URL } from "../api";

export default function CommentList({
  book_id,
  token,
  userStatus,
  user_id,
  setUpdateRatingIfChanged,
}) {
  const [comments, setComments] = useState([]);
  const [updateIfChanged, setUpdateIfChanged] = useState(null);
  const [commentText, setCommentText] = useState("");
  const [commentRating, setCommentRating] = useState(0);
  async function fetchComments() {
    try {
      console.log("Attempting to fetch comments from book_id:" + book_id);
      const response = await fetch(`${BASE_URL}/comments/book/${book_id}`);
      const results = await response.json();
      console.log(results.comments);
      setComments(results.comments);
      console.log("Fetched results from fetchComments()", results);
      return results;
    } catch (err) {
      console.error("Trouble fetching CommentList!", err);
    }
  }
  async function handleAdd(e) {
    e.preventDefault();

    const url = `${BASE_URL}/comments`;
    console.log("Adding comment from ", url);

    const comment = {};
    comment.book_id = book_id;
    comment.user_id = user_id;
    comment.content = commentText;
    comment.rating = commentRating;
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(comment),
      });
      const result = await response.json();
      setComments([...comments, result]);
      setUpdateRatingIfChanged(result);

      console.log("This comment was added", result);
    } catch (error) {
      console.error(error);
    }
  }

  useEffect(() => {
    fetchComments();
  }, [updateIfChanged]);
  return (
    <>
      <div className="commentlist">
        <h3>Comments</h3>

        {user_id && (
          <div className="">
            <label className="comment-rating">
              <input
                type="text"
                placeholder="Enter Comment Here"
                value={commentText}
                onChange={(e) => {
                  setCommentText(e.target.value);
                }}
              />
              <br />
              <input
                id="number"
                type="number"
                value={commentRating}
                step=".1"
                min="0"
                max="5"
                onChange={(e) => {
                  setCommentRating(e.target.value);
                }}
              />
              <button id="add-comment" onClick={handleAdd}>
                ADD COMMENT & RATING
              </button>{" "}
            </label>
            <br />
          </div>
        )}

        {comments &&
          comments.map((comment) => {
            return (
              <>
                <Comment
                  comment={comment}
                  token={token}
                  userStatus={userStatus}
                  setUpdateIfChanged={setUpdateIfChanged}
                  key={comment.comment_id}
                />
              </>
            );
          })}
      </div>
    </>
  );
}
