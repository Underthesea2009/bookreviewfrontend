import React, { useEffect, useState } from "react";
import Genre from "./Genre";
import AddGenre from "./AddGenre";
import { BASE_URL } from "../api";

const GenreList = () => {
  const [genres, setGenres] = useState([]);
  const [updateIfChanged, setUpdateIfChanged] = useState(null);

  async function fetchGenres() {
    try {
      const response = await fetch(`${BASE_URL}/genres`);
      const results = await response.json();
      setGenres(results.allGenres);
      console.log("Fetched results from fetchGenres()", results);
      return results;
    } catch (err) {
      console.error("Trouble fetching GenreList!", err);
    }
  }

  useEffect(() => {
    fetchGenres();
  }, [updateIfChanged]);
  return (
    <div>
      <AddGenre setUpdateIfChanged={setUpdateIfChanged} />
      <h2>Genre List</h2>
      <div>
        {genres &&
          genres.map((genre) => {
            return (
              <Genre
                genre={genre}
                setUpdateIfChanged={setUpdateIfChanged}
                key={genre.genre_id}
              />
            );
          })}
      </div>
    </div>
  );
};

export default GenreList;