import { useEffect, useState } from "react";
import { BASE_URL } from "../api";
import GenresForBook from "./GenresForBook";
import CommentList from "./CommentList";
import RatingView from "./RatingView";
import BookEdit from "./BookEdit";

export default function Book({
  book,
  token,
  userStatus,
  setUpdateIfChanged,
  user_id,
  setUpdateRatingIfChanged,
}) {
  const [genres, setGenres] = useState([]);
  const [showDetail, setShowDetail] = useState(false);
  const [isShowingEditBook, setIsShowingEditBook] = useState(false);

  async function handleDetailClick() {
    setShowDetail(!showDetail);
  }
  async function handleDelete() {
    const url = `${BASE_URL}/books/${book.book_id}`;
    console.log("Deleting post from ", url);

    try {
      const response = await fetch(url, {
        method: "DELETE",
      });
      setUpdateIfChanged(response);
      console.log("This book was deleted", response);
    } catch (error) {
      console.log(error);
    }
  }

  async function fetchGenres() {
    const url = `${BASE_URL}/bookGenres/${book.book_id}`;

    try {
      const response = await fetch(url);
      const result = await response.json();
      console.log("fetchGenres: book_id", book.book_id);
      console.log("fetchGenresForBook", result.genres);
      setGenres(result.genres);
    } catch (error) {
      console.error(error);
    }
  }

  useEffect(() => {
    fetchGenres();
  }, []);

  return (
    <>
      <div className="containers">
        <img
          className={showDetail ? "image-detail" : "image"}
          src={book.image_url}
        ></img>
        <div className="flexgrow">
          <div className="info title">{book.title}</div>
          <br />
          <div className="info">{book.author}</div>
          <div className="description">
            <p>{book.description} </p>

            <GenresForBook genres={genres} />

            {showDetail && (
              <CommentList
                book_id={book.book_id}
                token={token}
                userStatus={userStatus}
                user_id={user_id}
                setUpdateIfChanged={setUpdateIfChanged}
                setUpdateRatingIfChanged={setUpdateRatingIfChanged}
              />
            )}
          </div>
        </div>

        <br />
        <div id="delete" className="items">
          {userStatus === "admin" && (
            <div>
              <button
                onClick={() => {
                  handleDelete();
                }}
              >
                DELETE
              </button>
            </div>
          )}
          <br />
          <RatingView style={{ width: 200 }} rating={book.rating} />
          <br />
          <br />
          <button className="commentButton" onClick={() => handleDetailClick()}>
            {showDetail ? "HIDE COMMENTS" : "SHOW COMMENTS"}
          </button>
        </div>
      </div>
      {userStatus === "admin" && (
        <h2 className="subtitles">
          Edit Book:
          <button
            style={{ marginLeft: 20, backgroundColor: "green", color: "white" }}
            onClick={() => {
              setIsShowingEditBook(!isShowingEditBook);
            }}
          >
            {isShowingEditBook ? "HIDE" : "SHOW"}
          </button>
        </h2>
      )}
      {isShowingEditBook && (
        <BookEdit book={book} setUpdateIfChanged={setUpdateIfChanged} />
      )}
      <div className="bottomBorder"></div>
      <br />
    </>
  );
}
