import React from "react";

import { useState } from "react";
import { BASE_URL } from "../api";
import GenrePickerView from "./GenrePickerView";

const AddBook = ({ setUpdateIfChanged }) => {
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [description, setDescription] = useState("");
  const [active, setActive] = useState(true);
  const [image_Url, setImage_Url] = useState("");
  const [selectedGenres, setSelectedGenres] = useState([]);

  async function handleAdd(e) {
    e.preventDefault();

    const url = `${BASE_URL}/books`;
    console.log("Adding book from ", url);

    const book = {};
    book.title = title;
    book.author = author;
    book.rating = 5.0;
    book.description = description;
    book.genre_id = 1;
    book.image_url = image_Url;
    book.active = true;

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(book),
      });
      const result = await response.json();
      console.log("This book was added", result);

      await addAllGenresToBook(result.book_id);
      setTitle("");
      setAuthor("");
      setDescription("");
      setImage_Url("");
      setSelectedGenres([]);
      setUpdateIfChanged(result);
    } catch (error) {
      console.error(error);
    }
  }

  async function addAllGenresToBook(book_id) {
    selectedGenres.forEach(async (genre) => {
      await addGenreToBook(genre, book_id);
    });
    console.log("addAllGenresToBook: selectedGenres = ", selectedGenres);
  }

  async function addGenreToBook(genre, book_id) {
    const url = `${BASE_URL}/bookGenres/${book_id}`;
    const book_genre = {
      book_id: book_id,
      genre_id: genre.genre_id,
    };

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(book_genre),
      });
      const data = await response.json();
      console.log(data);
    } catch (error) {
      console.error(error);
    }
  }

  return (
    <div className="mb-4">
      <form onSubmit={handleAdd}>
        <div className="form-row">
          <div className="col">
            <input
              type="text"
              className="form-control"
              placeholder="Title"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
              }}
            />
          </div>
          <div className="col">
            <input
              className="form-control"
              type="text"
              placeholder="Author"
              value={author}
              onChange={(e) => {
                setAuthor(e.target.value);
              }}
            />
          </div>
          <div className="col">
            <input
              className="form-control"
              type="text"
              placeholder="Description"
              value={description}
              onChange={(e) => {
                setDescription(e.target.value);
              }}
            />
          </div>
          <div className="col">
            <input
              className="form-control"
              type="text"
              placeholder="Image URL"
              value={image_Url}
              onChange={(e) => {
                setImage_Url(e.target.value);
              }}
            />
            <br />
            <div>
              <br />
              <GenrePickerView
                selectedGenres={selectedGenres}
                setSelectedGenres={setSelectedGenres}
              />
            </div>
          </div>
          <br />
          <div>
            <br />
            <button id="add" type="submit">
              ADD
            </button>
          </div>
        </div>
        <br />
      </form>
    </div>
  );
};

export default AddBook;
