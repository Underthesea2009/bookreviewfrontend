import { useEffect, useState } from "react";
import { BASE_URL } from "../api";

export default function UserIntro({ token, userStatus, user_id }) {
  const [username, setUsername] = useState("Username Not Found");
  const [updateIfChanged, setUpdateIfChanged] = useState(null);
  async function fetchUsername() {
    try {
      console.log("Attempting to fetch user info by user ID:" + user_id);
      const response = await fetch(`${BASE_URL}/users/${user_id}`);
      const results = await response.json();
      console.log("Fetched results from fetchUsername()", results);
      console.log(results.user.username);
      setUsername(results.user.username);
      return results;
    } catch (err) {
      console.error("Trouble fetching UserCommentList!", err);
    }
  }

  useEffect(() => {
    fetchUsername();
  }, [updateIfChanged]);
  return (
    <>
      <div className="UserIntroduction">
        <h1>👋Welcome, {username}!</h1>
      </div>
    </>
  );
}
