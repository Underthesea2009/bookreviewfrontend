/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import { useEffect, useState } from "react";
import { BASE_URL } from "../api";

export default function UserComment({
  comment,
  token,
  userStatus,
  setUpdateIfChanged,
}) {
  const [username, setUsername] = useState("Unknown User");
  const [bookName, setBookName] = useState("Unknown Book");
  const [book, setBook] = useState("");
  const [isShowingEditComment, setIsShowingEditComment] = useState(false);
  const [newComment, setNewComment] = useState(comment);

  async function handleSaveComment() {
    const url = `${BASE_URL}/comments/${comment.comment_id}`;
    console.log("Updating comment from ", url);
    try {
      const response = await fetch(url, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newComment),
      });
      setUpdateIfChanged(response);
      console.log("This comment was updated", response);
    } catch (error) {
      console.error(error);
    }
  }
  async function handleDelete() {
    const url = `${BASE_URL}/comments/${comment.comment_id}`;
    console.log("Deleting comment from ", url);

    try {
      const response = await fetch(url, {
        method: "DELETE",
      });
      setUpdateIfChanged(response);
      console.log("This comment was deleted", response);
    } catch (error) {
      console.log(error);
    }
  }
  async function getUsernameByID() {
    const url = `${BASE_URL}/users/${comment.user_id}`;
    try {
      const response = await fetch(url);
      const results = await response.json();
      console.log("getting Username By ID: ");
      console.log(results);
      setUsername(results.user.username);
    } catch (error) {
      console.log(error);
    }
  }

  async function getBookByID() {
    const url = `${BASE_URL}/books/${comment.book_id}`;
    try {
      const response = await fetch(url);
      const results = await response.json();
      console.log("getting Book By ID: ");
      console.log(results);
      console.log(results.book.title);
      setBookName(results.book.title);
      setBook(results.book);
      console.log(results.book);
      console.log(results.book.book.image_url);
    } catch (error) {
      console.log(error);
    }
  }
  useEffect(() => {
    // getUsernameByID();
    getBookByID();
  }, []);
  return (
    <>
      <div className="container">
        <div className="flexgrow">
          <div>
            <img style={{ width: 100 }} src={book.image_url}></img>
          </div>

          <div> {bookName}</div>
          <span>{comment.content}</span>
          <div>{`Rating: ${comment.rating}`}</div>
          <br />
          <button onClick={handleDelete}>DELETE</button>
          {userStatus && (
            <>
              <h2 className="subtitles">
                Edit User Comment:
                <button
                  style={{
                    marginLeft: 20,
                    backgroundColor: "green",
                    color: "white",
                  }}
                  onClick={() => {
                    setIsShowingEditComment(!isShowingEditComment);
                  }}
                >
                  {isShowingEditComment ? "HIDE" : "SHOW"}
                </button>
              </h2>
              {isShowingEditComment && (
                <>
                  <input
                    type="text"
                    placeholder="Comment..."
                    value={newComment.content}
                    onChange={(e) => {
                      setNewComment({ ...newComment, content: e.target.value });
                    }}
                  />
                  <input
                    id="number"
                    type="number"
                    value={newComment.rating}
                    step=".1"
                    min="0"
                    max="5"
                    onChange={(e) => {
                      setNewComment({ ...newComment, rating: e.target.value });
                    }}
                  />
                  <br />
                  <button id="add" onClick={handleSaveComment}>
                    SAVE
                  </button>
                </>
              )}
            </>
          )}

          <div className="bottomBorder"></div>
        </div>
      </div>
    </>
  );
}
