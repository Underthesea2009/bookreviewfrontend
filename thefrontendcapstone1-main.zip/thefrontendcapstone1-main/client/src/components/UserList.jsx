import { useState, useEffect } from "react";
import User from "./User";
import { BASE_URL } from "../api";

export default function UserList() {
  const [users, setUsers] = useState([]);

  async function fetchUsers() {
    try {
      const response = await fetch(`${BASE_URL}/users`);
      const results = await response.json();
      setUsers(results.allUsers);
      console.log("Fetched results from fetchUsers()", results);
      return results.allUsers;
    } catch (err) {
      console.error("Trouble fetching UserList!", err);
    }
  }

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div className="userlist">
      {users &&
        users.map((user) => {
          return <User user={user} key={user.user_id} />;
        })}
    </div>
  );
}
