import { useEffect, useState } from "react";
import { BASE_URL } from "../api";

function GenrePickerView({ selectedGenres, setSelectedGenres }) {
  const [genres, setGenres] = useState([]);

  async function fetchAllGenres() {
    try {
      const url = `${BASE_URL}/genres`;
      const response = await fetch(url);
      const data = await response.json();
      console.log(data.allGenres);
      setGenres(data.allGenres);
      console.log(selectedGenres);
    } catch (error) {
      console.error(error);
    }
  }
  useEffect(() => {
    fetchAllGenres();
  }, []);

  function handleAdd(genre) {
    if (!isSelected(genre)) {
      setSelectedGenres([...selectedGenres, genre]);
      console.log("Selected Genre " + genre.name);
    } else {
      deselectGenre(genre);
      console.log("De-Selected Genre " + genre.name);
    }
  }
  function deselectGenre(genreToRemove) {
    const filtered = selectedGenres.filter((genre) => {
      return genre !== genreToRemove;
    });
    setSelectedGenres(filtered);
  }
  function isSelected(genre) {
    return selectedGenres.indexOf(genre) === -1 ? false : true;
  }
  return (
    <>
      <div className="container">
        {genres &&
          genres.map((genre) => {
            if (isSelected(genre)) {
              return (
                <span
                  className="genre-button-isSelected "
                  key={genre.genre_id}
                  onClick={() => {
                    handleAdd(genre);
                  }}
                >
                  {genre.name}
                </span>
              );
            } else {
              return (
                <span
                  className="genre-button"
                  key={genre.genre_id}
                  onClick={() => {
                    handleAdd(genre);
                  }}
                >
                  {genre.name}
                </span>
              );
            }
          })}
      </div>
    </>
  );
}

export default GenrePickerView;
